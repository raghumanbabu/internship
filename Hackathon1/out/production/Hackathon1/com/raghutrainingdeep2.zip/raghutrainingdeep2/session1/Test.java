package com.raghutrainingdeep2.session1;

public class Test {

    public static void main(String[] args) {
        int a = 10;
        int b = 8;
        System.out.println(a%=4);
    }

}
