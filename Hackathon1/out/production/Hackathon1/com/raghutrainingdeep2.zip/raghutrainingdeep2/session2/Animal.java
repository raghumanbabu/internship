package com.raghutrainingdeep2.session2;

public class Animal {

    int legs = 2;
    String name = "Horse";

}
