package com.raghutrainingdeep2.session2;

public enum JavaTrainingMembers {
    Anand,Lokesh,Arun,Vetri
}
