package com.raghutrainingdeep2.session2;

public enum Fruit {
    Mango,
    Apple,
    Orange,
    Banana
}
