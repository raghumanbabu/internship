package com.raghutrainingdeep2.session2;

public class Main {

    public static void main(String[] args) {
        Fruit a = Fruit.Apple;



        int b = 10;
        double f = (double)b; //10.0
        b = 20;

        Integer c = 10;
        long d = c.longValue();
        double e = c.doubleValue();
        System.out.println(d);
        System.out.println(e);
        System.out.println(c);
        c = 20;

        JavaTrainingMembers x;
        x = JavaTrainingMembers.Anand;

        Animal aa = new Animal(); // aa=100  100=(legs=2,name=204) 204=Horse
        System.out.println(aa);

    }

}
